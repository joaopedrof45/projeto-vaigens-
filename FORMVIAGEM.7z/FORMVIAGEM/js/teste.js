
    function teste() {

	var cpf = document.getElementById(cpf).value;
    var nome = document.getElementById(name).value;
    
    document.write(nome)

}
