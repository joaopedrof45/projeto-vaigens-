-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE Cadastro (
nome VARCHAR(255),
cpf INTEGER PRIMARY KEY,
rg INTEGER,
email VARCHAR(255),
emissor VARCHAR(255),
celular INTEGER,
telefoneTrabalho INTEGER,
cargo VARCHAR(255),
funcao VARCHAR(255),
setorLot VARCHAR(255),
cidadeLot VARCHAR(255),
superiorImediato VARCHAR(255),
coordenacaoSetorSede VARCHAR(255),
dataEmissao DATETIME,
agencia INTEGER,
contaCorrente INTEGER,
nomeBanco VARCHAR(255)
)

CREATE TABLE Evento (
tipoEvento VARCHAR(255),
descricaoEvento VARCHAR(255),
objetivoEvento VARCHAR(255),
localEvento VARCHAR(255),
inicio DATETIME,
termino DATETIME,
anexoDocs VARCHAR(255),
id INTEGER PRIMARY KEY,
cpf INTEGER,
FOREIGN KEY(cpf) REFERENCES Cadastro (cpf)
)


CREATE TABLE Itinerario(
    localOrigemIda varchar(255),
    dataSaidaIda DATETIME,
    localDestinoIda varchar(255),
    dataDestinoIda DATETIME,
    meioTransporteIda varchar(255),
     localOrigemVolta varchar(255),
    dataSaidaVolta DATETIME,
    localDestinoVolta varchar(255),
    dataDestinoVolta DATETIME,
    meioTransporteVolta varchar(255),
    valorTransporte integer,
    observacao varchar(255),
    tipoTranslado varchar(255),
    valorTranslado integer,
    descricao varchar(255),
    obscomplementar varchar(255),
    idEvento integer,
    FOREIGN KEY(idEvento) REFERENCES Evento (id)
)

