<!DOCTYPE html>
<html lang="pt-br">

<head>
    <title>Desafio</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="../image/png" href="images/icons/logoicon.ico" />
    <!--===============================================================================================-->

    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../css/util.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <!--===============================================================================================-->



    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../debut/scss/main.css">
    <link rel="stylesheet" href="../debut/scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="../debut/script/index.js"></script>


    <?php



    $status = session_status();

    if ($status == PHP_SESSION_ACTIVE) {
        //Destroy current and start new one


        if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome']) == true)) {
            unset($_SESSION['email']);
            unset($_SESSION['senha']);
            unset($_SESSION['nome']);

            session_destroy();
        } else {

            $logado = $_SESSION['email'];
            $logado2 = $_SESSION['senha'];
            $logado3 = $_SESSION['nome'];
        }
    }
    if ($status == PHP_SESSION_NONE) {





        session_start();
        if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome']) == true)) {
            unset($_SESSION['email']);
            unset($_SESSION['senha']);
            unset($_SESSION['nome']);
        } else {

            $logado = $_SESSION['email'];
            $logado2 = $_SESSION['senha'];
            $logado3 = $_SESSION['nome'];

            echo "<a style= color:red;>logado como : $logado3<a>";
        }
    }


    if ($logado3 == NULL) {
        header('location: ../view/index.html');
    }






    $username = "root";
    $password = "";

    $conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);

    try {
        $conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
    }



    ?>




</head>
<a style=color:blue; href="../controller/sair.php" method="POST">Sair</a>

<body id="wrapper">




    </section>

    <header>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <h1>Defensoria</h1><span>Pública do Paraná</span>
                    </a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <?php if ($logado3 == "Admin") {
                            echo "<li><a href='http://10.77.38.35/calcviagem1.2/'>Calcular Viagem</a></li>";
                        }
                        ?>

                        <li><a href="evento.php">Solicitar Viagem</a></li>
                        <li><a href='../controller/pesquisabanco.php'>Solicitações de Viagem</a></li>

                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>
        <!--/.nav-ends -->
    </header>

    <body>


        <div class="container-contact100">
            <div class="wrap-contact100">



                <span class="contact100-form-title">
                    <img width="80px" height="62px" src="../images/logo_dfpr-corte.png">
                    Calcula Viagem 2.0 - Dados do Evento


                </span>


                <br><span class="contact100-form-title">
                    Ida
                </span>

                <div class="wrap-input100 validate-input" data-validate="localSaida is required">
                    <input class="input100" id="localOrigemIda" type="text" name="localOrigemIda" placeholder="Local de Origem">
                    <label class="label-input100" for="localOrigemIda">
                        <span class="lnr lnr-map-marker"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Data e hora is required">
                    <input class="input100" id="dataSaidaIda" type="datetime-local" name="dataSaidaIda" placeholder="Data e horário de saída:&nbsp; ">
                    <label class="label-input100" for="dataSaidaIda">
                        <span class="lnr lnr-clock"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input" data-validate="localDestino is required">
                    <input class="input100" id="localDestinoIda" type="text" name="localDestinoIda" placeholder="Local de Destino">
                    <label class="label-input100" for="localDestinoIda">
                        <span class="lnr lnr-map-marker"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Data e hora is required">
                    <input class="input100" id="dataDestinoIda" type="datetime-local" name="dataDestinoIda" placeholder="Data e horário de Destino:&nbsp; ">
                    <label class="label-input100" for="dataDestinoIda">
                        <span class="lnr lnr-clock"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-select" data-validate="Meio de Transporte is required">
                    <select class="select3 input101 select-input1001" id="meioTransporteIda" type="text" name="meioTransporteIda">

                        <option selected disabled>Meio de Transporte</option>
                        <option>VEICULO OFICIAL</option>
                        <option>ONIBUS</option>
                        <option>AVIAO</option>
                        <option>VEICULO PARTICULAR</option>
                        <option>OUTROS</option>

                    </select>

                </div>

                <br><span class="contact100-form-title">
                    Volta
                </span>







                <div class="wrap-input100 validate-input" data-validate="localSaida is required">
                    <input class="input100" id="localOrigemVolta" type="text" name="localOrigemVolta" placeholder="Local de Origem">
                    <label class="label-input100" for="localOrigemVolta">
                        <span class="lnr lnr-map-marker"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Data e hora is required">
                    <input class="input100" id="dataSaidaVolta" type="datetime-local" name="dataSaidaVolta" placeholder="Data e horário de saída:&nbsp; ">
                    <label class="label-input100" for="dataSaidaVolta">
                        <span class="lnr lnr-clock"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input" data-validate="localDestino is required">
                    <input class="input100" id="localDestinoVolta" type="text" name="localDestinoVolta" placeholder="Local de Destino">
                    <label class="label-input100" for="localDestinoVolta">
                        <span class="lnr lnr-map-marker"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Data e hora is required">
                    <input class="input100" id="dataDestinoVolta" type="datetime-local" name="dataDestinoVolta" placeholder="Data e horário de Destino:&nbsp; ">
                    <label class="label-input100" for="dataDestinoVolta">
                        <span class="lnr lnr-clock"></span>
                    </label>
                </div>


                <br><span class="contact100-form-title2">
                    Informações Complementares
                </span>

                <div class="wrap-input100 validate-select" data-validate="Meio de Transporte is required">
                    <select class="select3 input101 select-input1001" id="meioTransporteVolta" type="text" name="meioTransporteVolta">

                        <option selected disabled>Meio de Transporte</option>
                        <option>VEICULO OFICIAL</option>
                        <option>ONIBUS</option>
                        <option>AVIAO</option>
                        <option>VEICULO PARTICULAR</option>
                        <option>OUTROS</option>

                    </select>

                </div>

                <div class="wrap-input100 validate-input" data-validate="Valor Transporte is required">
                    <input class="input100" id="valorTransporte" type="int" name="valorTransporte" placeholder="Valor do Transporte">
                    <label class="label-input100" for="valorTransporte">
                        <span class="lnr lnr-car"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input">
                    <input class="input100" id="obs" type="text" name="obs" placeholder="Observações">
                    <label class="label-input100" for="objetivo">
                        <span class="lnr lnr-text-align-left"></span>
                    </label>
                </div>



                <div class="wrap-input100 validate-select" data-validate="Tipo translado is required">
                    <select class="select3 input101 select-input1001" id="tipoTranslado" type="text" name="tipoTranslado">

                        <option selected disabled>Tipo de Translado</option>
                        <option>TAXI</option>
                        <option>PEDAGIO</option>
                        <option>VEICULO MARITIMO</option>
                        <option>OUTROS</option>

                    </select>

                </div>

                <div class="wrap-input100 validate-input">
                    <input class="input100" id="vlrTranslado" type="int" name="vlrTranslado" placeholder="Valor Translado">
                    <label class="label-input100" for="vlrTranslado">
                        <span class="lnr lnr-user"></span>
                    </label>
                </div>


                <div class="wrap-input100 validate-input">
                    <input class="input100" id="descricao" type="text" name="descricao" placeholder="Descrição">
                    <label class="label-input100" for="vlrTranslado">
                        <span class="lnr lnr-text-align-left"></span>
                    </label>
                </div>

                <div class="wrap-input100 validate-input">
                    <input class="input100" id="obsComplementares" type="text" name="obsComplementares" placeholder="Observações Complementares">
                    <label class="label-input100" for="vlrTranslado">
                        <span class="lnr lnr-text-align-left"></span>
                    </label>
                </div>


                <nav aria-label="Navegação de página exemplo">



                    <div class="container-contact100-form-btn">
                        <div class="wrap-contact100-form-btn">
                            <div class="contact100-form-bgbtn"></div>
                            <button class="contact100-form-btn">
                                Solicitar Viagem

                            </button>
                        </div>
                    </div>









                    <div id="dropDownSelect1"></div>

                    <!--===============================================================================================-->
                    <script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
                    <!--===============================================================================================-->
                    <script src="../vendor/animsition/js/animsition.min.js"></script>
                    <!--===============================================================================================-->
                    <script src="../vendor/bootstrap/js/popper.js"></script>
                    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
                    <!--===============================================================================================-->
                    <script src="../vendor/select2/select2.min.js"></script>
                    <!--===============================================================================================-->
                    <script src="../vendor/daterangepicker/moment.min.js"></script>
                    <script src="../vendor/daterangepicker/daterangepicker.js"></script>
                    <!--===============================================================================================-->
                    <script src="../vendor/countdowntime/countdowntime.js"></script>
                    <!--===============================================================================================-->
                    <script src="../js/main.js"></script>

                    <!-- Global site tag (gtag.js) - Google Analytics -->
                    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
                    <script>
                        window.dataLayer = window.dataLayer || [];

                        function gtag() {
                            dataLayer.push(arguments);
                        }
                        gtag('js', new Date());

                        gtag('config', 'UA-23581568-13');
                    </script>

    </body>

</html>