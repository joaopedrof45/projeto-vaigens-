<!DOCTYPE html>
<html lang="pt-br">

<head>
	<title>Desafio</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="../images/icons/logoicon.ico" />
	<!--===============================================================================================-->

	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<link rel="stylesheet" type="text/css" href="../css/main.css">
	<!--===============================================================================================-->



	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../debut/scss/main.css">
	<link rel="stylesheet" href="../debut/scss/skin.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
	<script src="../debut/script/index.js"></script>

</head>

<body id="wrapper">

	</section>

	<header>
		<nav class="navbar navbar-inverse">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="home.html">
						<h1>Defensoria</h1><span>Pública do Paraná</span>
					</a>
				</div>
				<div id="navbar" class="collapse navbar-collapse navbar-right">
					<ul class="nav navbar-nav">
						<li><a href="index.html">Login</a></li>


					</ul>
				</div>
				<!--/.nav-collapse -->
			</div>
		</nav>
		<!--/.nav-ends -->
	</header>


	</head>

	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" method="POST" action="../controller/cadastra_Controller.php">


				<span class="contact100-form-title">
					<img width="80px" height="62px" src="../images/logo_dfpr-corte.png">
					Calcula Viagem 2.0 - Dados Cadastrais

				</span>

				<div class="wrap-input100 validate-input" data-validate="Nome is required">
					<input class="input100" id="name" type="text" name="nome" placeholder="Nome">
					<label class="label-input100" for="name">
						<span class="lnr lnr-user"></span>
					</label>
				</div>



				<div class="wrap-input100 validate-input" data-validate="CPF is required">
					<input class="input100" id="cpf" type="integer" name="cpf" placeholder="CPF">
					<label class="label-input100" for="cpf">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="RG is required">
					<input class="input100" id="rg" type="integer" name="rg" placeholder="RG">
					<label class="label-input100" for="rg">
						<span class="lnr lnr-user"></span>
					</label>
				</div>


				<div class="wrap-input100 validate-input" data-validate="Nome is required">
					<input class="input100" id="name" type="password" name="senha1" placeholder="Senha">
					<label class="label-input100" for="name">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="Nome is required">
					<input class="input100" id="name" type="password" name="senha2" placeholder="Confirmar Senha">
					<label class="label-input100" for="name">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">
					<input class="input100" id="email" type="text" name="email" placeholder="Email">
					<label class="label-input100" for="email">
						<span class="lnr lnr-envelope"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="Emissor is required">
					<input class="input100" id="emissor" type="text" name="emissor" placeholder="Emissor">
					<label class="label-input100" for="emissor">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="celular is required">
					<input class="input100" id="celular" type="integer" name="celular" placeholder="Celular">
					<label class="label-input100" for="celular">
						<span class="lnr lnr-phone-handset"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="telefoneTrabalho is required">
					<input class="input100" id="telefoneTrabalho" type="integer" name="telefoneTrabalho" placeholder="Telefone de Trabalho">
					<label class="label-input100" for="telefoneTrabalho">
						<span class="lnr lnr-phone"></span>
					</label>
				</div>


				<div class="wrap-input100">
					<select class="select3 input101 select-input1001" id="cargo" type="text" name="cargo">

						<option selected disabled>Cargo</option>
						<option>DEFENSOR PÚBLICO</option>
						<option>SERVIDOR PÚBLICO</option>
						<option>ASSISTENTE TÉCNICO</option>
						<option>COMISSIONADO</option>
						<option>CEDIDO/VOLUNTÁRIO</option>
						<option>OUVIDOR</option>

					</select>
				</div>

				<div class="wrap-input100 validate-input" data-validate="Função is required">
					<input class="input100" id="funcao" type="text" name="funcao" placeholder="Função">
					<label class="label-input100" for="funcao">
						<span class="lnr lnr-user"></span>
					</label>
				</div>


				<div class="wrap-input100 validate-input" data-validate="Setor is required">
					<input class="input100" id="setorLot" type="text" name="setorLot" placeholder="Setor Lotação">
					<label class="label-input100" for="cidade">
						<span class="lnr lnr-map-marker"></span>
					</label>
				</div>




				<div class="wrap-input100 validate-input" data-validate="cidade is required">
					<input class="input100" id="cidadeLot" type="text" name="cidadeLot" placeholder="Cidade de lotação">
					<label class="label-input100" for="cidadeLot">
						<span class="lnr lnr-map-marker"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="superior is required">
					<input class="input100" id="superior" type="text" name="superior" placeholder="Superior imediato">
					<label class="label-input100" for="superior">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="coordenação is required">
					<input class="input100" id="coordenacao" type="text" name="coordenacao" placeholder="Coordenação da sede/setor">
					<label class="label-input100" for="coordenacao">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<br><span class="contact100-form-title2">
					Dados Bancários
				</span>



				<div class="wrap-input100 validate-input" data-validate="Agencia is required">
					<input class="input100" id="agencia" type="integer" name="agencia" placeholder="Agencia">
					<label class="label-input100" for="agencia">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="Conta Corrente is required">
					<input class="input100" id="contaCorrente" type="integer" name="contaCorrente" placeholder="Conta Corrente">
					<label class="label-input100" for="contaCorrente">
						<span class="lnr lnr-user"></span>
					</label>
				</div>

				<div class="wrap-input100 validate-input" data-validate="Banco is required">
					<input class="input100" id="banco" type="text" name="banco" placeholder="Banco">
					<label class="label-input100" for="banco">
						<span class="lnr lnr-apartment"></span>
					</label>
				</div>

				<div class="container-contact100-form-btn">
					<div class="wrap-contact100-form-btn">
						<div class="contact100-form-bgbtn"></div>
						<button class="contact100-form-btn">
							Cadastrar
					</div>
				</div>




			</form>
		</div>
	</div>





	<div id="dropDownSelect1"></div>

	<!--===============================================================================================-->
	<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/bootstrap/js/popper.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/daterangepicker/moment.min.js"></script>
	<script src="../vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/countdowntime/countdowntime.js"></script>
	<!--===============================================================================================-->
	<script src="../js/main.js"></script>

	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'UA-23581568-13');
	</script>


	</div>

</body>


</html>