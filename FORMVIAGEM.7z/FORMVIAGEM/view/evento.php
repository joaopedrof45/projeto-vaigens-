<!DOCTYPE html>
<html lang="pt-br">

<head>
    <title>Desafio</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="../images/icons/logoicon.ico" />
    <!--===============================================================================================-->

    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../css/util.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <!--===============================================================================================-->



    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../debut/scss/main.css">
    <link rel="stylesheet" href="../debut/scss/skin.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="../debut/script/index.js"></script>


    <?php
    session_start();
    if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome']) == true)) {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        unset($_SESSION['nome']);
    } else {

        $logado = $_SESSION['email'];
        $logado2 = $_SESSION['senha'];
        $logado3 = $_SESSION['nome'];
        echo "<a style= color:red;>logado como : $logado3<a>";
    }
    if ($logado3 == NULL) {
        header('location: ../view/index.html');
    }

    ?>

</head>

<a id="title1" style=color:blue; href="../controller/sair.php" method="POST">Sair</a>
<div id=ide>


    <body id="wrapper">

    <header>
<nav class="navbar navbar-inverse">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">
                <h1>Defensoria</h1><span>Pública do Paraná</span>
            </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse navbar-right">
            <ul class="nav navbar-nav">

                <?php if ($logado3 == "Admin") {
                    echo "<li><a href='http://10.77.38.35/calcviagem1.2/'>Calcular Viagem</a></li>";
                }
                ?>
                <li><a href="evento.php">Solicitar Viagem</a></li>
                <li><a href="#">Solicitações de Viagem</a></li>

            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
</nav>
<!--/.nav-ends -->
</header>
        


        <div class="container-contact100">
            <div class="wrap-contact100">
                <form class="contact100-form validate-form" method="POST" action="../controller/cadastraItinerario_Controller.php">

                    <span class="contact100-form-title">
                        <img width="80px" height="62px" src="../images/logo_dfpr-corte.png">
                        Calcula Viagem 2.0 - Dados do Evento
                    </span>

                    <div class="wrap-input100">
                        <select class="select3 input101 select-input1001" id="tipoEvento" type="text" name="tipoEvento">

                            <option selected disabled>Tipo de Evento</option>
                            <option>REUNIÃO</option>
                            <option>VISITA TÉCNICA</option>
                            <option>AUDIÊNCIA</option>
                            <option>EVENTOS</option>
                            <option>PALESTRAS</option>
                            <option>CURSOS</option>
                            <option>OUTROS</option>

                        </select>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="descricao is required">
                        <input class="input100" id="descricao" type="text" name="descricao1" placeholder="Descrição do evento">
                        <label class="label-input100" for="descricao">
                            <span class="lnr lnr-text-align-left"></span>
                        </label>
                    </div>


                    <div class="wrap-input100 validate-input" data-validate="Objetivo is required">
                        <input class="input100" id="objetivo" type="text" name="objetivo" placeholder="Objetivo do evento">
                        <label class="label-input100" for="objetivo">
                            <span class="lnr lnr-text-align-left"></span>
                        </label>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="local is required">
                        <input class="input100" id="localEvento" type="text" name="localEvento" placeholder="Local de realização do evento">
                        <label class="label-input100" for="localEvento">
                            <span class="lnr lnr-map-marker"></span>
                        </label>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="inicio is required">
                        <input class="input100" id="inicioEvento" type="date" name="inicioEvento" placeholder="Inicio:&nbsp; ">
                        <label class="label-input100" for="inicioEvento">
                            <span class="lnr lnr-clock"></span>
                        </label>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="termino is required">
                        <input class="input100" id="terminoEvento" type="date" name="terminoEvento" placeholder="Termino:&nbsp; ">
                        <label class="label-input100" for="terminoEvento">
                            <span class="lnr lnr-clock"></span>
                        </label>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="anexo is required">
                        <input class="input100" id="anexo" type="text" name="anexo" placeholder="Anexo">
                        <label class="label-input100" for="anexo">
                            <span class="lnr lnr-upload"></span>
                        </label>
                    </div>


                    <div class="container-contact100-form-btn">
                        <div class="wrap-contact100-form-btn">
                            <div class="contact100-form-bgbtn"></div>
                            <button class="contact100-form-btn" onclick="teste()">
                                Proximo
                            </button>
                        </div>
                    </div>



            </div>
        </div>

</div>

<div id="divd" style="display: none">
    <?php
    include_once("itinerario.php");
    ?>
    <div id="dropDownSelect1"></div>
</div>


<!--===============================================================================================-->
<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="../vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="../vendor/bootstrap/js/popper.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="../vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="../vendor/daterangepicker/moment.min.js"></script>
<script src="../vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="../vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="../js/main.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');


    function teste() {

        var cpf = document.getElementById('divd').style.display = "block";
        var idee = document.getElementById('ide').style.display = "none";
        var title = document.getElementById('title1').style.display = "none";





    }
</script>

</body>

</html>