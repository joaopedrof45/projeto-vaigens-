<?php

class BD{
	private $ConnHost;
	private $ConnUser;
	private $ConnPass;
	private $ConnDb;
	private $ConnDriver;

	function __construct(){
		$this->ConnDriver = "mysqli";
		$this->ConnHost   = "localhost";
		$this->ConnUser   = "root";
		$this->ConnPass   = "";
		$this->ConnDb     = "formviagem";		
	}	

	function Connect(){
		$conn = NULL;
		try{
			$conn = new PDO($this->ConnDriver.":host=".$this->ConnHost.";dbname=".$this->ConnDb,$this->ConnUser,$this->ConnPass);
		}catch (PDOException $e){
			$e->getMessage();
			echo "Atenção! Ocorreu um erro ao tentar se conectar ao banco de dados.<br />Caso o erro persistir contate o administrador do sistema!";
			exit();
		}
		return $conn;
	}
}
