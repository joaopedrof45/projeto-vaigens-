<?php

$username = "root";
$password = "";

$conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);

try {
    $conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $data = [
        'email' => $_POST['email'],
        'senha' => $_POST['senha'],
    ];

    $stmt = $conn->prepare("SELECT * FROM Cadastro WHERE email=:email and senha=:senha");
    $stmt->execute(['email' => $_POST['email'], 'senha' => $_POST['senha']]);

    $Cadastro = $stmt->fetchAll();
    if ($Cadastro == true) {
        foreach ($Cadastro as $Cadastro) {
            session_start();
            $_SESSION['email'] = $Cadastro['email'];
            $_SESSION['senha'] = $Cadastro['senha'];
            $_SESSION['nome'] = $Cadastro['nome'];
            $_SESSION['cpf'] = $Cadastro['cpf'];
            header('location: ../view/home2.php');
        }
    } else {

        echo "<script>alert('Login incorreto!');history.back();</script>";
    }
} catch (PDOException $e) {
    echo 'ERROR: ' . $e->getMessage();
}
