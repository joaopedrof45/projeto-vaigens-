<?php
session_start();

echo$_SESSION['email'],
$_SESSION['nome'],
$_SESSION['senha'],
$_SESSION['cpf'];
