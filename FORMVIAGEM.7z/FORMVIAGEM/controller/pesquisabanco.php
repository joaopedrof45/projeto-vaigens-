<!DOCTYPE php>

<html lang="pt-br">

<head>

    <head>
        <title>Desafio</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--===============================================================================================-->
        <link rel="icon" type="image/png" href="../images/icons/logoicon.ico" />
        <!--===============================================================================================-->

        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="../css/util.css">
        <link rel="stylesheet" type="text/css" href="../css/main.css">
        <!--===============================================================================================-->



        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="../debut/scss/main.css">
        <link rel="stylesheet" href="../debut/scss/skin.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>


    </head>



    <?php
    session_start();
    if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome']) == true)) {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        unset($_SESSION['nome']);
    } else {

        $logado = $_SESSION['email'];
        $logado2 = $_SESSION['senha'];
        $logado3 = $_SESSION['nome'];

        echo "<a style= color:red;>logado como : $logado3<a>";
    }
    if ($logado3 == NULL) {
        header('location: ../view/index.html');
    }


    ?>
    <a style=color:blue; href="../controller/sair.php" method="POST">Sair</a>

</head>

<body id="wrapper">



    </section>

    <header>
        <nav class="navbar navbar-inverse">

            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                        <span class="sr-only">Menu de navegação</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="home.html">
                        <h1>Defensoria</h1><span>Pública do Paraná</span>
                    </a>
                </div>
                <div id="navbar" class="collapse navbar-collapse navbar-right">

                    <ul class="nav navbar-nav">
                        <?php if ($logado3 == "Admin") {
                            echo "<li><a href='http://10.77.38.35/calcviagem1.2/'>Calcular Viagem</a></li>";
                        }
                        ?>
                        <li><a href="evento.php">Solicitar Viagem</a></li>
                        <li><a href="../controller/pesquisabanco.php">Solicitações de Viagem</a></li>


                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>

        </nav>
        <!--/.nav-ends -->
    </header>







    <div class="container-contact100">

            <form class="contact100-form validate-form">

              <?php




if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome']) == true)) {
  unset($_SESSION['email']);
  unset($_SESSION['senha']);
  unset($_SESSION['nome']);
} else {

  $logado = $_SESSION['email'];
  $logado2 = $_SESSION['senha'];
  $logado3 = $_SESSION['nome'];
  $logado4 = $_SESSION['cpf'];
}

$username = "root";
$password = "";

if ($logado3 == NULL) {
  header('location: ../view/home.html');
}





$conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);


try {
  $conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


  if ($logado3 == 'Admin') {
    $stmt = $conn->prepare("SELECT * FROM Evento");
    $stmt->execute();
    $Cadastro = $stmt->fetchAll();
echo"<table border='1px'>";

  foreach ($Cadastro as $value) {
$tipoevento=$value['tipoEvento'];
$descricaoEvento=$value['descricaoEvento'] ;
$objetivoEvento=$value['objetivoEvento'];
$localEvento=$value['localEvento'] ;
$inicio=$value['inicio'];
$termino=$value['termino'] ;
$anexoDocs=$value['anexoDocs'] ;
$cpf=$value['cpf'];
$id=$value['id'];

    echo"
<div align='center'>
<table border='1px' align='center'>

 <tr align='center'>
          <td >tipoevento</td>
          <td>descricaoEvento</td>
          <td>objetivoEvento</td>
          <td>localEvento</td>
          <td>inicio</td>
          <td>termino</td>
          <td>cpf</td>
          <td>tipoevento</td>
    </tr>
    <p align='center'>===============EVENTO=================</p><br>";
    echo"

    <tr align='center'>
          <td>$tipoevento</td>
          <td>$descricaoEvento</td>
          <td>$objetivoEvento</td>
          <td>$localEvento</td>
          <td>$inicio</td>
          <td>$termino</td>
          <td>$cpf</td>
          <td>$tipoevento</td>
    </tr>


    </table>
    
      <input type='button' value='some e aparece' onclick='teste()'>
    ";

    $novoid=$value['id'];
 
   $stmt2 = $conn->prepare("SELECT * FROM Itinerario where idEvento='$novoid'");
    $stmt2->execute();


    //aqui pega o id do evento e faz um for para mostrar os itinerarios de cada evento
    $Cadastro2 = $stmt2->fetchAll();


  foreach ($Cadastro2 as $value2) {
    
    echo" <p><br>===============ITINERARIO=================</p><br>";
 
$localOrigemIda=$value2['localOrigemIda'];
$dataSaidaIda=$value2['dataSaidaIda'];
$localDestinoIda=$value2['localDestinoIda'];
$dataDestinoIda=$value2['dataDestinoIda'];
$meioTransporteIda=$value2['meioTransporteIda']; 
$localOrigemVolta=$value2['localOrigemVolta'];
$dataSaidaVolta=$value2['dataSaidaVolta']; 
$localDestinoVolta=$value2['localDestinoVolta'];
$dataDestinoVolta=$value2['dataDestinoVolta']; 
$meioTransporteVolta=$value2['meioTransporteVolta'];
$valorTransporte=$value2['valorTransporte'];
$observacao=$value2['observacao'];
$tipoTranslado=$value2['tipoTranslado'] ;
$valorTranslado=$value2['valorTranslado'];
$descricao=$value2['descricao'];
$obscomplementar=$value2['obscomplementar'];
$idEvento=$value2['idEvento']; 
    

    echo"
    
<table border='1px' align='center'>

 <tr align='center'>
     <td>$localOrigemVolta</td>
<td>dataSaidaVolta</td>
<td>localDestinoVolta</td>
<td>dataDestinoVolta</td>
<td>meioTransporteVolta</td>
<td>valorTransporte</td>
<td>observacao</td>
<td>tipoTranslado</td>
<td>valorTranslado</td>
<td>descricao</td>
<td>obscomplementar</td>
<td>idEvento</td>

    </tr>";
    echo"

    <tr align='center'>
<td>$localOrigemVolta</td>
<td>$dataSaidaVolta</td>
<td>$localDestinoVolta</td>
<td>$dataDestinoVolta</td>
<td>$meioTransporteVolta</td>
<td>$valorTransporte</td>
<td>$observacao</td>
<td>$tipoTranslado</td>
<td>$valorTranslado</td>
<td>$descricao</td>
<td>$obscomplementar</td>
<td>$idEvento</td>

    </tr>

    </table>
    ";


  }

  }

  }else{

    echo"nao tem implementação ainda";
     echo"<br>VÁ PARA O ADMIN PARA VER :p";
  } 

} catch (PDOException $e) {
  echo 'ERROR: ' . $e->getMessage();
}


?>







            </form>
        </div>
    </div>



    <div id="dropDownSelect1"></div>


    <!--===============================================================================================-->
    <script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="../vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="../vendor/bootstrap/js/popper.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="../vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="../vendor/daterangepicker/moment.min.js"></script>
    <script src="../vendor/daterangepicker/daterangepicker.js"></script>
    <!--===============================================================================================-->
    <script src="../vendor/countdowntime/countdowntime.js"></script>
    <!--===============================================================================================-->
    <script src="../js/main.js"></script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>

  <script>
      function teste() {

        if (document.getElementById("idr").style.display === "none") {

          document.getElementById("idr").style.display = "block";

        } else {
          document.getElementById("idr").style.display = "none";
        }
      }
    </script>

</body>

</html>





