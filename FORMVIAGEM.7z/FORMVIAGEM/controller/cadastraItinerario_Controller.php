
<?php

include_once('../view/itinerario.php');








$status = session_status();

if ($status == PHP_SESSION_ACTIVE) {
  //Destroy current and start new one


  if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    unset($_SESSION['nome']);
    unset($_SESSION['cpf']);

    session_destroy();
  } else {

    $logado = $_SESSION['email'];
    $logado2 = $_SESSION['senha'];
    $logado3 = $_SESSION['nome'];
    $cpf = $_SESSION['cpf'];
  }
}
if ($status == PHP_SESSION_NONE) {





  session_start();
  if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    unset($_SESSION['nome']);
  } else {

    $logado = $_SESSION['email'];
    $logado2 = $_SESSION['senha'];
    $logado3 = $_SESSION['nome'];

    echo "<a style= color:red;>logado como : $logado3<a>";
  }
}




$username = "root";
$password = "";

$conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);

try {
  $conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


  //array do Evento
  $dataEvento = [
    'tipoEvento' => $_POST['tipoEvento'],
    'descricao1' => $_POST['descricao1'],
    'objetivo' => $_POST['objetivo'],
    'localEvento' => $_POST['localEvento'],
    'inicioEvento' => $_POST['inicioEvento'],
    'terminoEvento' => $_POST['terminoEvento'],
    'anexo' => $_POST['anexo'],
    'cpf' => $cpf


  ];




  $sql2 = "INSERT INTO Evento(tipoEvento,descricaoEvento,objetivoEvento,localEvento,inicio,termino,anexoDocs,cpf) values(:tipoEvento,:descricao1,:objetivo,:localEvento,:inicioEvento,:terminoEvento,:anexo,:cpf)";
  $stmt2 = $conn->prepare($sql2);
  $stmt2->execute($dataEvento);



  $VAR = $conn->lastInsertId();
} catch (PDOException $e) {
  echo 'ERROR: ' . $e->getMessage();
}


try {
  $conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //array do Itinerario
  $data = [
    'localOrigemIda' => $_POST['localOrigemIda'],
    'dataSaidaIda' => $_POST['dataSaidaIda'],
    'localDestinoIda' => $_POST['localDestinoIda'],
    'dataDestinoIda' => $_POST['dataDestinoIda'],
    'meioTransporteIda' => $_POST['meioTransporteIda'],
    'localOrigemVolta' => $_POST['localOrigemVolta'],
    'dataSaidaVolta' => $_POST['dataSaidaVolta'],
    'localDestinoVolta' => $_POST['localDestinoVolta'],
    'dataDestinoVolta' => $_POST['dataDestinoVolta'],
    'meioTransporteVolta' => $_POST['meioTransporteVolta'],
    'valorTransporte' => $_POST['valorTransporte'],
    'obs' => $_POST['obs'],
    'tipoTranslado' => $_POST['tipoTranslado'],
    'vlrTranslado' => $_POST['vlrTranslado'],
    'descricao' => $_POST['descricao'],
    'obsComplementares' => $_POST['obsComplementares'],
    'idEvento' => $VAR,


  ];

  $sql = "INSERT INTO Itinerario(localOrigemIda,dataSaidaIda,localDestinoIda,dataDestinoIda,meioTransporteIda,localOrigemVolta,dataSaidaVolta,localDestinoVolta,dataDestinoVolta,meioTransporteVolta,valorTransporte,observacao,tipoTranslado,valorTranslado,descricao,obscomplementar,idEvento)

VALUES (:localOrigemIda,:dataSaidaIda,:localDestinoIda,:dataDestinoIda,:meioTransporteIda,:localOrigemVolta,:dataSaidaVolta,:localDestinoVolta,:dataDestinoVolta,:meioTransporteVolta,:valorTransporte,:obs,:tipoTranslado,:vlrTranslado,:descricao,:obsComplementares,:idEvento)";
  $stmt = $conn->prepare($sql);
  $stmt->execute($data);
} catch (PDOException $e) {
  echo 'ERROR: ' . $e->getMessage();
}
