
<?php

$username = "root";
$password = "";

$conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);

try {
    $conn = new PDO('mysql:host=localhost;dbname=protocolos', $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if ($_POST['senha1'] == $_POST['senha2']) {
        $data = [
            'Nome' => $_POST['nome'],
            'Cpf' => $_POST['cpf'],
            'Rg' => $_POST['rg'],
            'Email' => $_POST['email'],
            'Emissor' => $_POST['emissor'],
            'Celular' => $_POST['celular'],
            'TelefoneTrabalho' => $_POST['telefoneTrabalho'],
            'Cargo' => $_POST['cargo'],
            'Funcao' => $_POST['funcao'],
            'setorLot' => $_POST['setorLot'],
            'cidadeLot' => $_POST['cidadeLot'],
            'Superior' => $_POST['superior'],
            'Coordenacao' => $_POST['coordenacao'],
            'Agencia' => $_POST['agencia'],
            'Contacorrente' => $_POST['contaCorrente'],
            'Banco' => $_POST['banco'],
            'Senha' => $_POST['senha1'],
        ];

        $varr = $_POST['email'];



        $sql1 = "SELECT email from Cadastro where email='$varr'";
        $stmt2 = $conn->prepare($sql1);
        $stmt2->execute();
        $row = $stmt2->fetch();
    } else {
        echo "senha nao confere";
    }





    if ($row == 0) {

        $sql = "INSERT INTO Cadastro (nome,cpf,rg,email,emissor,celular,telefoneTrabalho,cargo,funcao,setorLot,cidadeLot,superiorImediato,coordenacaoSetorSede,dataEmissao,agencia,contaCorrente,nomeBanco,senha) 
VALUES (:Nome, :Cpf,:Rg,:Email,:Emissor,:Celular,:TelefoneTrabalho,:Cargo,:Funcao,:setorLot,:cidadeLot,:Superior,:Coordenacao, Now(),:Agencia,:Contacorrente,:Banco,:Senha)";
        $stmt = $conn->prepare($sql);
        $stmt->execute($data);

        header("Location: /ambienteteste/FORMVIAGEM/view/home.html");
    } else {

        echo "<script>alert('Email Já cadastrado!');history.back();</script>";
    }
} catch (PDOException $e) {
    $var=$e->getMessage();

    echo "<script>alert('Erro: $var ');</script>";
    echo "<script>history.go(-1)</script>";
}
